"""Paradox AntiCheat - GUI Package"""
