"""Paradox AntiCheat - Settings Commands"""
